#!/usr/bin/env python3
"""Tables and plot data for the interpolation section of the report.

Reads interpolation_results/interpolation_all.csv (written by
isosurface_interpolation_experiments) and prints LaTeX table rows; writes
pgfplots data files to Thesis_01/data/interp_*.dat.

    python3 Thesis_01/scripts/interpolation_tables.py        (from the project root)
"""
import csv
import math
import os
from collections import defaultdict

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CSV = os.path.join(ROOT, "interpolation_results", "interpolation_all.csv")
DATA = os.path.join(ROOT, "Thesis_01", "data")

TEX_F = {
    "A1_x2+y2-z2+xyz": "$x^2+y^2-z^2+xyz$",
    "A2_x2+y2+z3": "$x^2+y^2+z^3$",
    "A2_x2-y2+z3": "$x^2-y^2+z^3$",
    "A2_x3+y3+z2+x2": "$x^3+y^3+z^2+x^2$",
    "D4_x2+y3+z3": "$x^2+y^3+z^3$",
    "D4_x2+y3-3yz2": "$x^2+y^3-3yz^2$",
    "E6_x3+y3+z3": "$x^3+y^3+z^3$",
    "E6_x3+y3-z3": "$x^3+y^3-z^3$",
    "E6_x3+y3+z3+xyz": "$x^3+y^3+z^3+xyz$",
    "E6_x3+2y3+3z3+2xyz": "$x^3+2y^3+3z^3+2xyz$",
}
TEX_G = {"1": "$1$", "x": "$x$", "x+y": "$x+y$", "x^2+y^2-z^2": "$x^2+y^2-z^2$"}
TYPE = {"A1": "$A_1$", "A2": "$A_2$", "D4": "$D_4$", "E6~": "$\\tilde E_6$"}

rows = list(csv.DictReader(open(CSV)))
R = {}
for r in rows:
    R[(r["surface"], r["G"], float(r["eps"]), int(r["resolution"]), r["method"])] = r
surfaces = list(dict.fromkeys(r["surface"] for r in rows))
gs = list(dict.fromkeys(r["G"] for r in rows))
eps = sorted({float(r["eps"]) for r in rows}, reverse=True)
types = {r["surface"]: r["type"] for r in rows}


def val(s, g, e, n, m, col):
    v = R[(s, g, e, n, m)][col]
    return float("inf") if v in ("NA", "") else float(v)  # NA: no part of the surface in Q


def f4(x):
    return "empty" if x == float("inf") else f"{x:.4f}"


def endpoint(s, g, e, n, col):
    return max(val(s, g, e, n, "endpoint_minus", col), val(s, g, e, n, "endpoint_plus", col))


def vmid(s, g, e, n, col):
    return max(val(s, g, e, n, "vertex_mid_from_minus", col), val(s, g, e, n, "vertex_mid_from_plus", col))


def slope(xs, ys):
    pts = [(math.log(x), math.log(y)) for x, y in zip(xs, ys) if 0 < y < float("inf")]
    if len(pts) < 3:
        return float("nan")
    mx = sum(p[0] for p in pts) / len(pts)
    my = sum(p[1] for p in pts) / len(pts)
    return sum((p[0] - mx) * (p[1] - my) for p in pts) / sum((p[0] - mx) ** 2 for p in pts)


def f3(x):
    return "--" if not math.isfinite(x) else f"{x:.3f}"


def e2(x):
    if not math.isfinite(x):
        return "--"
    m, ex = f"{x:.1e}".split("e")
    return f"${m}\\cdot10^{{{int(ex)}}}$"


N = 128
print("% ---- Table 1: errors at eps = 1e-2 and 1e-3, N = 128 (H_Q) ----")
for s in surfaces:
    for g in gs:
        cells = []
        for e in (1e-2, 1e-3):
            cells += [endpoint(s, g, e, N, "hausdorff_Q"), vmid(s, g, e, N, "hausdorff_Q"),
                      val(s, g, e, N, "sdf_average", "hausdorff_Q"), val(s, g, e, N, "exact_vertex_mid", "hausdorff_Q")]
        print(f"{TEX_F[s] if g == gs[0] else ''} & {TEX_G[g]} & " + " & ".join(f4(c) for c in cells) + " \\\\")
    print("\\midrule" if s != surfaces[-1] else "")
print("direct S0 errors N=128:", {s: round(val(s, gs[0], eps[0], N, 'direct_S0', 'hausdorff_Q'), 4) for s in surfaces})

print("\n% ---- Table 2: slopes vs eps of exact interpolation (N = 128) ----")
slopes = defaultdict(list)
for s in surfaces:
    for g in gs:
        end = [endpoint(s, g, e, N, "hausdorff_Q") for e in eps]
        exn = [val(s, g, e, N, "exact_vertex_mid", "hausdorff_near_P") for e in eps]
        exf = [val(s, g, e, N, "exact_vertex_mid", "hausdorff_away_from_P") for e in eps]
        endf = [endpoint(s, g, e, N, "hausdorff_away_from_P") for e in eps]
        a, b, c, d = slope(eps, end), slope(eps, exn), slope(eps, endf), slope(eps, exf)
        slopes[g].append((a, b, c, d))
        print(f"{TEX_F[s] if g == gs[0] else ''} & {TEX_G[g]} & {f3(a)} & {f3(b)} & {f3(c)} & {f3(d)} & {e2(exf[0])} & {e2(exf[2])} \\\\")
    print("\\midrule" if s != surfaces[-1] else "")

print("\n% ---- Topology at N = 128 (components / euler / dist P) ----")
topo = defaultdict(int)
for s in surfaces:
    for g in gs:
        for e in eps:
            d0 = R[(s, g, e, N, "direct_S0")]
            for m in ("endpoint_minus", "endpoint_plus", "vertex_mid_from_minus", "vertex_mid_from_plus",
                      "sdf_average", "exact_vertex_mid"):
                r = R[(s, g, e, N, m)]
                same = r["components"] == d0["components"] and r["euler"] == d0["euler"]
                topo[(m, "same")] += same
                topo[(m, "all")] += 1
                topo[(m, "holes")] += int(r["hole_edges"]) > 0
                topo[(m, "nonmanifold")] += int(r["nonmanifold_edges"]) > 0
                topo[(m, "flipped")] += r["flipped_triangles"] not in ("", "0")
for m in ("endpoint_minus", "endpoint_plus", "vertex_mid_from_minus", "vertex_mid_from_plus", "sdf_average", "exact_vertex_mid"):
    print(m, {k: topo[(m, k)] for k in ("same", "all", "holes", "nonmanifold", "flipped")})

print("\n% ---- topology per surface/G at N=128, eps=1e-3: (comp, euler) for S0, -, +, mid-, mid+, sdf ----")
for s in surfaces:
    for g in gs:
        e = 1e-3
        t = [(R[(s, g, e, N, m)]["components"], R[(s, g, e, N, m)]["euler"]) for m in
             ("direct_S0", "endpoint_minus", "endpoint_plus", "vertex_mid_from_minus", "vertex_mid_from_plus", "sdf_average")]
        print(s, g, t)

print("\n% ---- resolution dependence (eps = 1e-3), median over all pairs of H_Q ----")
for n in (32, 64, 128):
    def med(xs):
        xs = sorted(xs)
        return xs[len(xs) // 2]
    line = []
    for m in ("direct_S0", "endpoint", "vertex_mid", "sdf_average", "exact_vertex_mid"):
        xs = []
        for s in surfaces:
            for g in gs:
                if m == "endpoint":
                    xs.append(endpoint(s, g, 1e-3, n, "hausdorff_Q"))
                elif m == "vertex_mid":
                    xs.append(vmid(s, g, 1e-3, n, "hausdorff_Q"))
                else:
                    xs.append(val(s, g, 1e-3, n, m, "hausdorff_Q"))
        line.append(med(xs))
    print(n, " & ".join(f"{x:.4f}" for x in line))

print("\n% ---- dist(P, reconstruction), N=128, eps=1e-3 ----")
for s in surfaces:
    print(s, [f"{g}:{float(R[(s, g, 1e-3, N, 'exact_vertex_mid')]['dist_P_to_mesh']):.1e}/{float(R[(s, g, 1e-3, N, 'sdf_average')]['dist_P_to_mesh']):.1e}" for g in gs])

print("field average max error:", max(float(r["field_average_max_error"]) for r in rows))
print("correspondence failures:", sum(int(r["correspondence_failures"]) for r in rows),
      "distance failures:", sum(int(r["distance_failures"]) for r in rows))

# pgfplots data: error vs eps for a few pairs at N = 128
os.makedirs(DATA, exist_ok=True)
for tag, s, g in (("A1_1", "A1_x2+y2-z2+xyz", "1"), ("A1_x", "A1_x2+y2-z2+xyz", "x"),
                  ("E6a_x", "E6_x3+y3+z3", "x"), ("A2a_x", "A2_x2+y2+z3", "x")):
    with open(os.path.join(DATA, f"interp_{tag}.dat"), "w") as f:
        f.write("eps endpoint vertexmid sdf exact exactnear exactfar endpointfar direct\n")
        for e in sorted(eps):
            f.write(" ".join(f"{v:.6e}" for v in (
                e, endpoint(s, g, e, N, "hausdorff_Q"), vmid(s, g, e, N, "hausdorff_Q"),
                val(s, g, e, N, "sdf_average", "hausdorff_Q"), val(s, g, e, N, "exact_vertex_mid", "hausdorff_Q"),
                val(s, g, e, N, "exact_vertex_mid", "hausdorff_near_P"),
                val(s, g, e, N, "exact_vertex_mid", "hausdorff_away_from_P"),
                endpoint(s, g, e, N, "hausdorff_away_from_P"), val(s, g, e, N, "direct_S0", "hausdorff_Q"))) + "\n")
print("wrote", DATA)
